import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { getAuthHeaders } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import QuizTimer from '@/components/quiz/quiz-timer';
import { Brain, CheckCircle, XCircle, Clock, Trophy, RotateCcw, PlayCircle } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface Quiz {
  id: string;
  title: string;
  questions: QuizQuestion[];
  status: 'not_started' | 'in_progress' | 'completed';
  score?: number;
  totalQuestions: number;
  timeLimit?: number;
  timeSpent?: number;
  completedAt?: string;
  createdAt: string;
}

export default function QuizPage() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Quiz state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [isQuizStarted, setIsQuizStarted] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [timeUp, setTimeUp] = useState(false);

  // Fetch available quizzes if no ID provided
  const { data: quizzes = [] } = useQuery({
    queryKey: ['/api/quizzes'],
    queryFn: async () => {
      const response = await fetch('/api/quizzes', {
        headers: getAuthHeaders()
      });
      return response.json();
    },
    enabled: !id
  });

  // Fetch specific quiz if ID provided
  const { data: quiz, isLoading } = useQuery<Quiz>({
    queryKey: ['/api/quizzes', id],
    queryFn: async () => {
      const response = await fetch(`/api/quizzes/${id}`, {
        headers: getAuthHeaders()
      });
      if (!response.ok) {
        throw new Error('Quiz non trouvé');
      }
      return response.json();
    },
    enabled: !!id
  });

  // Submit quiz mutation
  const submitQuizMutation = useMutation({
    mutationFn: async ({ quizId, answers, timeSpent }: { quizId: string; answers: { [key: number]: number }; timeSpent: number }) => {
      const response = await fetch(`/api/quizzes/${quizId}/submit`, {
        method: 'PATCH',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ answers, timeSpent })
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la soumission du quiz');
      }
      return response.json();
    },
    onSuccess: (data) => {
      setShowResults(true);
      toast({
        title: "Quiz terminé !",
        description: `Votre score : ${data.score}% (${data.correctAnswers}/${data.totalQuestions})`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Start quiz
  const startQuiz = () => {
    setIsQuizStarted(true);
    setStartTime(new Date());
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setShowResults(false);
  };

  // Submit quiz
  const submitQuiz = () => {
    if (!quiz || !startTime) return;
    
    setIsSubmitting(true);
    const timeSpent = Math.floor((Date.now() - startTime.getTime()) / 1000);
    
    submitQuizMutation.mutate({
      quizId: quiz.id,
      answers: selectedAnswers,
      timeSpent
    });
  };

  // Handle answer selection
  const selectAnswer = (answerIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: answerIndex
    }));
  };

  // Navigation
  const goToNextQuestion = () => {
    if (currentQuestionIndex < (quiz?.questions.length || 0) - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  // Handle time up
  const handleTimeUp = () => {
    setTimeUp(true);
    submitQuiz();
  };

  // Quiz list view (no ID provided)
  if (!id) {
    return (
      <div className="min-h-screen py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Quiz</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Testez vos connaissances avec des quiz générés par IA
            </p>
          </div>

          {quizzes.length === 0 ? (
            <Card className="p-12 text-center">
              <div className="text-gray-400 mb-4">
                <Brain className="w-16 h-16 mx-auto" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Aucun quiz disponible
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Téléchargez des documents pour générer automatiquement des quiz.
              </p>
              <Button onClick={() => setLocation('/documents')} className="bg-primary-500 hover:bg-primary-600">
                Ajouter des documents
              </Button>
            </Card>
          ) : (
            <div className="space-y-4">
              {quizzes.map((quizItem: Quiz) => (
                <Card key={quizItem.id} className="p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                          {quizItem.title}
                        </h3>
                        <Badge className={
                          quizItem.status === 'completed' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                            : quizItem.status === 'in_progress'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                        }>
                          {quizItem.status === 'completed' ? 'Terminé' : 
                           quizItem.status === 'in_progress' ? 'En cours' : 'Pas commencé'}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                        <span>{quizItem.totalQuestions} questions</span>
                        {quizItem.timeLimit && (
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {quizItem.timeLimit} min
                          </span>
                        )}
                        {quizItem.completedAt && quizItem.score !== undefined && (
                          <span className="flex items-center text-green-600">
                            <Trophy className="w-4 h-4 mr-1" />
                            Score: {quizItem.score}%
                          </span>
                        )}
                      </div>
                      
                      <p className="text-xs text-gray-500">
                        Créé le {format(new Date(quizItem.createdAt), 'dd/MM/yyyy à HH:mm', { locale: fr })}
                      </p>
                    </div>
                    
                    <div className="flex space-x-2">
                      {quizItem.status === 'completed' ? (
                        <Button
                          variant="outline"
                          onClick={() => setLocation(`/quiz/${quizItem.id}`)}
                        >
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Refaire
                        </Button>
                      ) : (
                        <Button
                          onClick={() => setLocation(`/quiz/${quizItem.id}`)}
                          className="bg-primary-500 hover:bg-primary-600"
                        >
                          <PlayCircle className="w-4 h-4 mr-2" />
                          {quizItem.status === 'in_progress' ? 'Continuer' : 'Commencer'}
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Chargement du quiz...</p>
        </div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Quiz introuvable</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-4">Ce quiz n'existe pas ou n'est plus disponible.</p>
          <Button onClick={() => setLocation('/quiz')}>
            Retour aux quiz
          </Button>
        </Card>
      </div>
    );
  }

  // Quiz not started or completed state
  if (!isQuizStarted && quiz.status !== 'in_progress' && !showResults) {
    return (
      <div className="min-h-screen py-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="p-8">
            <CardHeader className="text-center pb-8">
              <div className="w-16 h-16 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl">{quiz.title}</CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{quiz.totalQuestions}</div>
                  <div className="text-sm text-blue-600 dark:text-blue-400">Questions</div>
                </div>
                {quiz.timeLimit && (
                  <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">{quiz.timeLimit}</div>
                    <div className="text-sm text-green-600 dark:text-green-400">Minutes</div>
                  </div>
                )}
                <div className="p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">IA</div>
                  <div className="text-sm text-purple-600 dark:text-purple-400">Généré par IA</div>
                </div>
              </div>
              
              {quiz.status === 'completed' && quiz.score !== undefined && (
                <Card className="p-4 bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Trophy className="w-5 h-5 text-green-600" />
                      <span className="font-medium text-green-700 dark:text-green-300">Quiz déjà terminé</span>
                    </div>
                    <Badge className="bg-green-600 text-white">Score: {quiz.score}%</Badge>
                  </div>
                  {quiz.completedAt && (
                    <p className="text-sm text-green-600 mt-2">
                      Terminé le {format(new Date(quiz.completedAt), 'dd/MM/yyyy à HH:mm', { locale: fr })}
                    </p>
                  )}
                </Card>
              )}
              
              <div className="text-center space-y-4">
                <Button
                  onClick={startQuiz}
                  className="bg-gradient-to-r from-primary-500 to-secondary-500 hover:from-primary-600 hover:to-secondary-600 text-white px-8 py-3 text-lg"
                >
                  <PlayCircle className="w-5 h-5 mr-2" />
                  {quiz.status === 'completed' ? 'Refaire le quiz' : 'Commencer le quiz'}
                </Button>
                
                <div className="text-sm text-gray-500">
                  {quiz.timeLimit ? (
                    <p>⚠️ Attention : vous avez {quiz.timeLimit} minutes pour terminer ce quiz.</p>
                  ) : (
                    <p>💡 Prenez votre temps, il n'y a pas de limite de temps.</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100;

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Quiz Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{quiz.title}</h1>
            {quiz.timeLimit && startTime && (
              <QuizTimer
                duration={quiz.timeLimit * 60}
                onTimeUp={handleTimeUp}
                startTime={startTime}
              />
            )}
          </div>
          
          <div className="flex items-center space-x-4 mb-4">
            <span className="text-sm text-gray-500">
              Question {currentQuestionIndex + 1} sur {quiz.questions.length}
            </span>
            <div className="flex-1">
              <Progress value={progress} className="h-2" />
            </div>
          </div>
        </div>

        {/* Question Card */}
        <Card className="mb-6">
          <CardContent className="p-8">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
              {currentQuestion.question}
            </h2>
            
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => selectAnswer(index)}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                    selectedAnswers[currentQuestionIndex] === index
                      ? 'border-primary-500 bg-primary-50 dark:bg-primary-950'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      selectedAnswers[currentQuestionIndex] === index
                        ? 'border-primary-500 bg-primary-500'
                        : 'border-gray-300'
                    }`}>
                      {selectedAnswers[currentQuestionIndex] === index && (
                        <div className="w-2 h-2 rounded-full bg-white"></div>
                      )}
                    </div>
                    <span className="flex-1">{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={goToPreviousQuestion}
            disabled={currentQuestionIndex === 0}
          >
            Précédent
          </Button>
          
          <div className="flex space-x-2">
            {currentQuestionIndex === quiz.questions.length - 1 ? (
              <Button
                onClick={submitQuiz}
                disabled={isSubmitting || Object.keys(selectedAnswers).length === 0}
                className="bg-secondary-500 hover:bg-secondary-600"
              >
                {isSubmitting ? 'Soumission...' : 'Terminer le quiz'}
              </Button>
            ) : (
              <Button
                onClick={goToNextQuestion}
                disabled={selectedAnswers[currentQuestionIndex] === undefined}
                className="bg-primary-500 hover:bg-primary-600"
              >
                Suivant
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
