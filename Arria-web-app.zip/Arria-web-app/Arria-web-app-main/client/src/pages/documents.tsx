import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getAuthHeaders } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import UploadZone from '@/components/documents/upload-zone';
import SynthesisPreview from '@/components/ai/synthesis-preview';
import { FileText, Download, Eye, Zap, Clock, CheckCircle, AlertCircle, Loader } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface Document {
  id: string;
  title: string;
  originalName: string;
  fileType: string;
  fileSize: number;
  content?: string;
  summary?: string;
  keyPoints?: string[];
  synthesisStatus: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: string;
  subjectId?: string;
}

interface Subject {
  id: string;
  name: string;
  color: string;
}

export default function Documents() {
  const { toast } = useToast();
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);

  // Fetch documents
  const { data: documents = [], isLoading, refetch } = useQuery<Document[]>({
    queryKey: ['/api/documents'],
    queryFn: async () => {
      const response = await fetch('/api/documents', {
        headers: getAuthHeaders()
      });
      if (!response.ok) {
        throw new Error('Erreur lors du chargement des documents');
      }
      return response.json();
    }
  });

  // Fetch subjects
  const { data: subjects = [] } = useQuery<Subject[]>({
    queryKey: ['/api/subjects'],
    queryFn: async () => {
      const response = await fetch('/api/subjects', {
        headers: getAuthHeaders()
      });
      return response.json();
    }
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getStatusBadge = (status: Document['synthesisStatus']) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"><CheckCircle className="w-3 h-3 mr-1" /> Synthèse terminée</Badge>;
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"><Loader className="w-3 h-3 mr-1 animate-spin" /> En traitement</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"><AlertCircle className="w-3 h-3 mr-1" /> Échec</Badge>;
      default:
        return <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"><Clock className="w-3 h-3 mr-1" /> En attente</Badge>;
    }
  };

  const handleGenerateQuiz = async (document: Document) => {
    try {
      const response = await fetch(`/api/documents/${document.id}/generate-quiz`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ numQuestions: 10 })
      });

      if (!response.ok) {
        throw new Error('Erreur lors de la génération du quiz');
      }

      const quiz = await response.json();
      toast({
        title: "Quiz généré",
        description: "Le quiz a été créé avec succès à partir de ce document.",
      });

      // Redirect to quiz page
      window.location.href = `/quiz/${quiz.id}`;
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-400">Chargement de vos documents...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Documents</h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2">
            Téléchargez vos documents et laissez l'IA créer des synthèses personnalisées
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Documents List */}
          <div className="lg:col-span-2 space-y-6">
            {/* Upload Zone */}
            <UploadZone onUploadSuccess={refetch} subjects={subjects} />

            {/* Documents Grid */}
            {documents.length === 0 ? (
              <Card className="p-12 text-center">
                <div className="text-gray-400 mb-4">
                  <FileText className="w-16 h-16 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Aucun document
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Téléchargez votre premier document pour commencer la synthèse automatique.
                </p>
              </Card>
            ) : (
              <div className="space-y-4">
                {documents.map((document) => {
                  const subject = subjects.find(s => s.id === document.subjectId);
                  return (
                    <Card key={document.id} className="p-6 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4 flex-1">
                          <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                            <FileText className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="font-semibold text-gray-900 dark:text-white truncate">
                                {document.title}
                              </h3>
                              {getStatusBadge(document.synthesisStatus)}
                              {subject && (
                                <Badge variant="outline" style={{ backgroundColor: subject.color + '20', color: subject.color }}>
                                  {subject.name}
                                </Badge>
                              )}
                            </div>
                            
                            <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                              <span>{formatFileSize(document.fileSize)}</span>
                              <span>{document.fileType}</span>
                              <span>{format(new Date(document.createdAt), 'dd/MM/yyyy à HH:mm', { locale: fr })}</span>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setSelectedDocument(document)}
                              >
                                <Eye className="w-4 h-4 mr-2" />
                                Voir détails
                              </Button>
                              
                              {document.synthesisStatus === 'completed' && (
                                <Button
                                  size="sm"
                                  onClick={() => handleGenerateQuiz(document)}
                                  className="bg-secondary-500 hover:bg-secondary-600"
                                >
                                  <Zap className="w-4 h-4 mr-2" />
                                  Générer quiz
                                </Button>
                              )}
                              
                              <Button variant="outline" size="sm">
                                <Download className="w-4 h-4 mr-2" />
                                Télécharger
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>

          {/* Document Details Sidebar */}
          <div>
            {selectedDocument ? (
              <SynthesisPreview document={selectedDocument} />
            ) : (
              <Card className="p-6">
                <div className="text-center text-gray-500">
                  <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Sélectionnez un document pour voir ses détails et sa synthèse IA.</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
