import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { getAuthHeaders } from '@/lib/auth';
import { queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useUser } from '@/hooks/use-user';
import { Calendar, Clock, Plus, CheckCircle2, AlertCircle, Circle, BookOpen, Briefcase } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface Subject {
  id: string;
  name: string;
  color: string;
}

interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate?: string;
  status: 'pending' | 'in_progress' | 'completed';
  priority: number;
  subjectId?: string;
  estimatedHours?: number;
}

interface Course {
  id: string;
  title: string;
  description?: string;
  startDate: string;
  endDate: string;
  subjectId?: string;
}

export default function Planning() {
  const { user } = useUser();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<'tasks' | 'courses'>('tasks');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // Fetch subjects
  const { data: subjects = [] } = useQuery<Subject[]>({
    queryKey: ['/api/subjects'],
    queryFn: async () => {
      const response = await fetch('/api/subjects', {
        headers: getAuthHeaders()
      });
      return response.json();
    }
  });

  // Fetch tasks
  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
    queryFn: async () => {
      const response = await fetch('/api/tasks', {
        headers: getAuthHeaders()
      });
      return response.json();
    }
  });

  // Fetch courses (for students)
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
    queryFn: async () => {
      const response = await fetch('/api/courses', {
        headers: getAuthHeaders()
      });
      return response.json();
    },
    enabled: user?.role === 'student'
  });

  const createTaskMutation = useMutation({
    mutationFn: async (newTask: Partial<Task>) => {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newTask)
      });
      if (!response.ok) throw new Error('Erreur lors de la création de la tâche');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Tâche créée",
        description: "La nouvelle tâche a été ajoutée avec succès."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Task> & { id: string }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'PATCH',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updates)
      });
      if (!response.ok) throw new Error('Erreur lors de la mise à jour');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Tâche mise à jour",
        description: "Les modifications ont été sauvegardées."
      });
    }
  });

  const createSubjectMutation = useMutation({
    mutationFn: async (newSubject: { name: string; color: string }) => {
      const response = await fetch('/api/subjects', {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newSubject)
      });
      if (!response.ok) throw new Error('Erreur lors de la création de la matière');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/subjects'] });
      toast({
        title: "Matière créée",
        description: "La nouvelle matière a été ajoutée."
      });
    }
  });

  const handleCreateTask = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const taskData = {
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      dueDate: formData.get('dueDate') ? new Date(formData.get('dueDate') as string).toISOString() : undefined,
      priority: parseInt(formData.get('priority') as string),
      subjectId: formData.get('subjectId') as string || undefined,
      estimatedHours: formData.get('estimatedHours') ? parseInt(formData.get('estimatedHours') as string) : undefined,
    };

    createTaskMutation.mutate(taskData);
  };

  const toggleTaskStatus = (task: Task) => {
    let newStatus: Task['status'];
    if (task.status === 'pending') newStatus = 'in_progress';
    else if (task.status === 'in_progress') newStatus = 'completed';
    else newStatus = 'pending';

    updateTaskMutation.mutate({ id: task.id, status: newStatus });
  };

  const getStatusIcon = (status: Task['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'in_progress':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      default:
        return <Circle className="w-5 h-5 text-gray-400" />;
    }
  };

  const getPriorityColor = (priority: number) => {
    switch (priority) {
      case 3: return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 2: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default: return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    }
  };

  const getPriorityLabel = (priority: number) => {
    switch (priority) {
      case 3: return 'Haute';
      case 2: return 'Moyenne';
      default: return 'Basse';
    }
  };

  if (tasksLoading) {
    return (
      <div className="min-h-screen py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-400">Chargement de votre planning...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Planning</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              {user?.role === 'student' 
                ? 'Gérez vos cours et devoirs' 
                : 'Organisez vos tâches et projets'
              }
            </p>
          </div>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary-500 hover:bg-primary-600">
                <Plus className="w-4 h-4 mr-2" />
                Nouvelle tâche
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Créer une nouvelle tâche</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateTask} className="space-y-4">
                <div>
                  <Label htmlFor="title">Titre *</Label>
                  <Input id="title" name="title" placeholder="Nom de la tâche" required />
                </div>
                
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" name="description" placeholder="Description détaillée..." />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="priority">Priorité</Label>
                    <Select name="priority" defaultValue="1">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Basse</SelectItem>
                        <SelectItem value="2">Moyenne</SelectItem>
                        <SelectItem value="3">Haute</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="estimatedHours">Durée estimée (h)</Label>
                    <Input id="estimatedHours" name="estimatedHours" type="number" min="1" placeholder="2" />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="dueDate">Date d'échéance</Label>
                  <Input id="dueDate" name="dueDate" type="datetime-local" />
                </div>
                
                {subjects.length > 0 && (
                  <div>
                    <Label htmlFor="subjectId">Matière</Label>
                    <Select name="subjectId">
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner une matière" />
                      </SelectTrigger>
                      <SelectContent>
                        {subjects.map((subject) => (
                          <SelectItem key={subject.id} value={subject.id}>
                            <div className="flex items-center">
                              <div 
                                className="w-3 h-3 rounded-full mr-2" 
                                style={{ backgroundColor: subject.color }}
                              />
                              {subject.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Annuler
                  </Button>
                  <Button type="submit" disabled={createTaskMutation.isPending}>
                    {createTaskMutation.isPending ? 'Création...' : 'Créer'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-6">
          <Button
            variant={activeTab === 'tasks' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('tasks')}
            className="flex items-center"
          >
            {user?.role === 'student' ? <BookOpen className="w-4 h-4 mr-2" /> : <Briefcase className="w-4 h-4 mr-2" />}
            {user?.role === 'student' ? 'Devoirs & Projets' : 'Tâches'}
          </Button>
          {user?.role === 'student' && (
            <Button
              variant={activeTab === 'courses' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('courses')}
              className="flex items-center"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Emploi du temps
            </Button>
          )}
        </div>

        {/* Tasks View */}
        {activeTab === 'tasks' && (
          <div className="space-y-4">
            {tasks.length === 0 ? (
              <Card className="p-12 text-center">
                <div className="text-gray-400 mb-4">
                  <Briefcase className="w-16 h-16 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Aucune tâche
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Créez votre première tâche pour commencer à organiser votre travail.
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)} className="bg-primary-500 hover:bg-primary-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Créer une tâche
                </Button>
              </Card>
            ) : (
              <div className="space-y-4">
                {tasks.map((task) => {
                  const subject = subjects.find(s => s.id === task.subjectId);
                  return (
                    <Card key={task.id} className="p-6 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4 flex-1">
                          <button
                            onClick={() => toggleTaskStatus(task)}
                            className="mt-1 hover:scale-110 transition-transform"
                          >
                            {getStatusIcon(task.status)}
                          </button>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className={`font-semibold ${task.status === 'completed' ? 'line-through text-gray-500' : 'text-gray-900 dark:text-white'}`}>
                                {task.title}
                              </h3>
                              <Badge className={getPriorityColor(task.priority)}>
                                {getPriorityLabel(task.priority)}
                              </Badge>
                              {subject && (
                                <Badge variant="outline" className="border-0" style={{ backgroundColor: subject.color + '20', color: subject.color }}>
                                  {subject.name}
                                </Badge>
                              )}
                            </div>
                            
                            {task.description && (
                              <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">{task.description}</p>
                            )}
                            
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              {task.dueDate && (
                                <div className="flex items-center">
                                  <Calendar className="w-4 h-4 mr-1" />
                                  {format(new Date(task.dueDate), 'dd/MM/yyyy à HH:mm', { locale: fr })}
                                </div>
                              )}
                              {task.estimatedHours && (
                                <div className="flex items-center">
                                  <Clock className="w-4 h-4 mr-1" />
                                  {task.estimatedHours}h estimées
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Courses View (Students only) */}
        {activeTab === 'courses' && user?.role === 'student' && (
          <div className="space-y-4">
            {courses.length === 0 ? (
              <Card className="p-12 text-center">
                <div className="text-gray-400 mb-4">
                  <Calendar className="w-16 h-16 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Aucun cours planifié
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Vos cours apparaîtront ici une fois ajoutés.
                </p>
              </Card>
            ) : (
              <div className="space-y-4">
                {courses.map((course) => {
                  const subject = subjects.find(s => s.id === course.subjectId);
                  return (
                    <Card key={course.id} className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold text-gray-900 dark:text-white">{course.title}</h3>
                            {subject && (
                              <Badge variant="outline" style={{ backgroundColor: subject.color + '20', color: subject.color }}>
                                {subject.name}
                              </Badge>
                            )}
                          </div>
                          
                          {course.description && (
                            <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">{course.description}</p>
                          )}
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center">
                              <Calendar className="w-4 h-4 mr-1" />
                              {format(new Date(course.startDate), 'dd/MM/yyyy HH:mm', { locale: fr })}
                            </div>
                            <span>→</span>
                            <div>
                              {format(new Date(course.endDate), 'dd/MM/yyyy HH:mm', { locale: fr })}
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
