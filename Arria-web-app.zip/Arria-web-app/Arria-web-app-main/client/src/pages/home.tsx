import { useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Brain, 
  Calendar, 
  ChartLine, 
  Users, 
  Medal, 
  MessageCircleQuestion, 
  ListTodo, 
  ChartBar, 
  Lightbulb,
  Rocket,
  Play,
  CheckCircle,
  Shield,
  Smartphone,
  Sparkles,
  WandSparkles,
  Flame,
  Star,
  Trophy,
  Plus,
  Upload,
  FileText,
  Clock
} from 'lucide-react';

// Component for displaying satisfied users counter
function SatisfiedUsersCounter() {
  const { data: userStats } = useQuery({
    queryKey: ['/api/stats/users'],
    queryFn: async () => {
      const response = await fetch('/api/stats/users');
      return response.json();
    }
  });

  const satisfiedCount = userStats?.satisfiedUsers || 0;

  return (
    <div className="flex items-center">
      <Users className="w-4 h-4 mr-2" />
      {satisfiedCount > 0 ? `${satisfiedCount} utilisateurs satisfaits` : 'Soyez le premier utilisateur satisfait !'}
    </div>
  );
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<'student' | 'professional'>('student');

  const studentFeatures = [
    {
      icon: <Calendar className="w-6 h-6" />,
      title: "Planning de cours",
      description: "Organisez vos cours, révisions et échéances dans un calendrier intelligent qui s'adapte à votre rythme.",
      gradient: "from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950",
      iconBg: "bg-blue-500"
    },
    {
      icon: <ChartLine className="w-6 h-6" />,
      title: "Suivi de progression",
      description: "Visualisez vos progrès par matière avec des graphiques détaillés et des statistiques motivantes.",
      gradient: "from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950",
      iconBg: "bg-green-500"
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: "Synthèse IA",
      description: "L'IA génère automatiquement des résumés et points clés de vos documents pour optimiser vos révisions.",
      gradient: "from-purple-50 to-violet-50 dark:from-purple-950 dark:to-violet-950",
      iconBg: "bg-purple-500"
    },
    {
      icon: <MessageCircleQuestion className="w-6 h-6" />,
      title: "Quiz interactifs",
      description: "Des quiz personnalisés générés à partir de vos cours avec minuteur pour tester vos connaissances.",
      gradient: "from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950",
      iconBg: "bg-amber-500"
    },
    {
      icon: <Medal className="w-6 h-6" />,
      title: "Système de badges",
      description: "Gagnez des badges et débloquez des récompenses en atteignant vos objectifs d'apprentissage.",
      gradient: "from-red-50 to-pink-50 dark:from-red-950 dark:to-pink-950",
      iconBg: "bg-red-500"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Collaboration",
      description: "Partagez vos synthèses et collaborez avec d'autres étudiants dans des espaces dédiés.",
      gradient: "from-teal-50 to-cyan-50 dark:from-teal-950 dark:to-cyan-950",
      iconBg: "bg-teal-500"
    }
  ];

  const professionalFeatures = [
    {
      icon: <ListTodo className="w-6 h-6" />,
      title: "Gestion des tâches",
      description: "Organisez vos projets et tâches avec des priorités intelligentes et des rappels automatiques.",
      gradient: "from-slate-50 to-gray-50 dark:from-slate-950 dark:to-gray-950",
      iconBg: "bg-slate-600"
    },
    {
      icon: <ChartBar className="w-6 h-6" />,
      title: "Productivité",
      description: "Suivez votre temps de travail et analysez vos performances avec des métriques détaillées.",
      gradient: "from-emerald-50 to-green-50 dark:from-emerald-950 dark:to-green-950",
      iconBg: "bg-emerald-500"
    },
    {
      icon: <Lightbulb className="w-6 h-6" />,
      title: "Assistance IA",
      description: "Recevez des suggestions de priorités et des conseils personnalisés pour optimiser votre workflow.",
      gradient: "from-indigo-50 to-blue-50 dark:from-indigo-950 dark:to-blue-950",
      iconBg: "bg-indigo-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-gray-900 dark:to-blue-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-500/10 to-secondary-500/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary-50 dark:bg-primary-950 text-primary-700 dark:text-primary-300 text-sm font-medium">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Intelligence artificielle intégrée
                </div>
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 dark:text-white leading-tight">
                  Organisez votre 
                  <span className="bg-gradient-to-r from-primary-500 to-secondary-500 bg-clip-text text-transparent">
                    réussite
                  </span>
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed">
                  L'application intelligente qui transforme vos études et votre travail en succès mesurable. 
                  Planifiez, suivez et progressez avec l'IA.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-primary-500 hover:bg-primary-600 text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all">
                  <Link href="/register">
                    <Rocket className="w-5 h-5 mr-2" />
                    Commencer gratuitement
                  </Link>
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="text-lg font-semibold"
                  onClick={() => {
                    const element = document.getElementById('dashboard');
                    element?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  <Play className="w-5 h-5 mr-2" />
                  Voir la démo
                </Button>
              </div>
              
              <div className="flex items-center space-x-6 text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-secondary-500 mr-2" />
                  Gratuit pour commencer
                </div>
                <div className="flex items-center">
                  <Shield className="w-4 h-4 text-secondary-500 mr-2" />
                  Données sécurisées
                </div>
                <div className="flex items-center">
                  <Smartphone className="w-4 h-4 text-secondary-500 mr-2" />
                  Responsive
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-3xl transform rotate-3 opacity-10"></div>
              <Card className="relative rounded-3xl shadow-2xl animate-float">
                <CardContent className="p-8">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Tableau de bord</h3>
                      <div className="flex space-x-2">
                        <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                        <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gradient-to-r from-primary-50 to-primary-100 dark:from-primary-950 dark:to-primary-900 p-4 rounded-xl">
                        <div className="text-2xl font-bold text-primary-700 dark:text-primary-300">0%</div>
                        <div className="text-sm text-primary-600 dark:text-primary-400">Progression</div>
                      </div>
                      <div className="bg-gradient-to-r from-secondary-50 to-secondary-100 dark:from-secondary-950 dark:to-secondary-900 p-4 rounded-xl">
                        <div className="text-2xl font-bold text-secondary-700 dark:text-secondary-300">0</div>
                        <div className="text-sm text-secondary-600 dark:text-secondary-400">Tâches</div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="text-center text-gray-500 dark:text-gray-400">
                        <div className="text-sm">Commencez à utiliser Orria</div>
                        <div className="text-xs">pour voir votre progression</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white">
              Une solution complète pour votre réussite
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Que vous soyez étudiant ou professionnel, Orria s'adapte à vos besoins avec des outils intelligents
            </p>
          </div>
          
          {/* User Type Toggle */}
          <div className="flex justify-center mb-12">
            <div className="bg-gray-100 dark:bg-gray-700 p-1 rounded-xl">
              <Button
                variant={activeTab === 'student' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('student')}
                className="px-8 py-3 text-sm font-semibold"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Étudiants
              </Button>
              <Button
                variant={activeTab === 'professional' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('professional')}
                className="px-8 py-3 text-sm font-semibold"
              >
                <ListTodo className="w-4 h-4 mr-2" />
                Professionnels
              </Button>
            </div>
          </div>
          
          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {(activeTab === 'student' ? studentFeatures : professionalFeatures).map((feature, index) => (
              <Card key={index} className={`group p-8 bg-gradient-to-br ${feature.gradient} hover:shadow-lg transition-all border`}>
                <CardContent className="p-0">
                  <div className={`w-12 h-12 ${feature.iconBg} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform text-white`}>
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Dashboard Preview Section */}
      <section id="dashboard" className="py-20 bg-gradient-to-r from-slate-50 to-blue-50 dark:from-gray-900 dark:to-blue-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white">
              Un tableau de bord qui s'adapte à vous
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Interface intuitive et personnalisable pour suivre vos progrès en temps réel
            </p>
          </div>
          
          <Card className="rounded-3xl shadow-2xl overflow-hidden">
            {/* Dashboard Header */}
            <div className="bg-gradient-to-r from-primary-500 to-secondary-500 p-6 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Votre tableau de bord</h3>
                    <p className="text-white/80 text-sm">Interface personnalisée</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <div className="text-2xl font-bold">0%</div>
                    <div className="text-sm text-white/80">Progression globale</div>
                  </div>
                  <div className="w-16 h-16 relative">
                    <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 36 36">
                      <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="2"/>
                      <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="white" strokeWidth="2" strokeDasharray="0, 100"/>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Dashboard Content */}
            <CardContent className="p-8">
              <div className="grid lg:grid-cols-3 gap-8">
                {/* Stats Cards */}
                <div className="lg:col-span-2 space-y-6">
                  <div className="grid md:grid-cols-3 gap-4">
                    <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-100 dark:border-blue-800">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">0</div>
                          <div className="text-sm text-blue-600 dark:text-blue-400">Cours cette semaine</div>
                        </div>
                        <FileText className="w-8 h-8 text-blue-500" />
                      </div>
                    </Card>
                    <Card className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-green-100 dark:border-green-800">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-2xl font-bold text-green-700 dark:text-green-300">0</div>
                          <div className="text-sm text-green-600 dark:text-green-400">Quiz complétés</div>
                        </div>
                        <CheckCircle className="w-8 h-8 text-green-500" />
                      </div>
                    </Card>
                    <Card className="p-6 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950 border-amber-100 dark:border-amber-800">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-2xl font-bold text-amber-700 dark:text-amber-300">0h</div>
                          <div className="text-sm text-amber-600 dark:text-amber-400">Temps d'étude</div>
                        </div>
                        <Clock className="w-8 h-8 text-amber-500" />
                      </div>
                    </Card>
                  </div>
                  
                  {/* Progress Chart */}
                  <Card className="p-6 bg-gray-50 dark:bg-gray-700">
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Progression par matière</h4>
                    <div className="text-center py-8">
                      <p className="text-gray-500 dark:text-gray-400">
                        Ajoutez des matières pour voir votre progression
                      </p>
                    </div>
                  </Card>
                </div>
                
                {/* Right Column */}
                <div className="space-y-6">
                  {/* Achievement Badges */}
                  <Card className="p-6 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-purple-100 dark:border-purple-800">
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Badges récents</h4>
                    <div className="text-center py-8">
                      <div className="text-purple-400 mb-4">
                        <Trophy className="w-12 h-12 mx-auto" />
                      </div>
                      <p className="text-gray-500 dark:text-gray-400">
                        Aucun badge obtenu
                      </p>
                      <p className="text-sm text-gray-400 mt-1">
                        Commencez à étudier pour débloquer des badges !
                      </p>
                    </div>
                  </Card>
                  
                  {/* Quick Actions */}
                  <div className="space-y-2">
                    <Button asChild className="w-full bg-primary-500 hover:bg-primary-600 text-white">
                      <Link href="/quiz">
                        <Plus className="w-4 h-4 mr-2" />
                        Nouveau quiz
                      </Link>
                    </Button>
                    <Button asChild className="w-full bg-secondary-500 hover:bg-secondary-600 text-white">
                      <Link href="/documents">
                        <Upload className="w-4 h-4 mr-2" />
                        Ajouter document
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* AI Features Showcase */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900 text-purple-700 dark:text-purple-300 text-sm font-medium">
                  <Brain className="w-4 h-4 mr-2" />
                  Intelligence Artificielle
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white">
                  L'IA qui comprend votre façon d'apprendre
                </h2>
                <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed">
                  Notre intelligence artificielle analyse vos documents, génère des synthèses personnalisées et crée des quiz adaptés à votre niveau.
                </p>
              </div>
              
              <div className="space-y-4">
                {[
                  { icon: FileText, title: 'Synthèse automatique', desc: 'Transforme vos cours en résumés structurés avec les points clés' },
                  { icon: MessageCircleQuestion, title: 'Quiz intelligents', desc: 'Génère des questions personnalisées basées sur vos documents' },
                  { icon: ChartLine, title: 'Analyse de progression', desc: 'Identifie vos forces et points d\'amélioration automatiquement' }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center mt-1">
                      <feature.icon className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">{feature.title}</h3>
                      <p className="text-gray-600 dark:text-gray-300">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <Button 
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-4 text-lg font-semibold"
                onClick={() => {
                  window.open('https://openai.com/api/', '_blank');
                }}
              >
                <WandSparkles className="w-5 h-5 mr-2" />
                Découvrir l'IA d'Orria
              </Button>
            </div>
            
            <div className="relative">
              <Card className="bg-gradient-to-r from-purple-500 to-pink-500 p-1 rounded-2xl">
                <CardContent className="bg-white dark:bg-gray-800 rounded-2xl p-8">
                  <div className="space-y-6">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Interface IA</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">
                        Votre synthèse IA apparaîtra ici
                      </p>
                    </div>
                    
                    <div className="text-center py-8">
                      <div className="text-purple-400 mb-4">
                        <FileText className="w-12 h-12 mx-auto" />
                      </div>
                      <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Aucun document uploadé</h4>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">
                        Commencez par uploader un document pour voir la magie de l'IA !
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white">
              Tarifs simples et transparents
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Commencez gratuitement et évoluez selon vos besoins
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Free Plan */}
            <Card className="p-8 text-center relative">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Gratuit</h3>
                <div className="text-3xl font-bold text-gray-900 dark:text-white mb-6">0€<span className="text-sm text-gray-500">/mois</span></div>
                <ul className="space-y-3 text-gray-600 dark:text-gray-300 mb-8">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />5 documents par mois</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />10 quiz par mois</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />Synthèse IA basique</li>
                </ul>
                <Button asChild className="w-full">
                  <Link href="/register">Commencer gratuitement</Link>
                </Button>
              </CardContent>
            </Card>
            
            {/* Pro Plan */}
            <Card className="p-8 text-center relative border-primary-500 border-2">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm font-semibold">Populaire</span>
              </div>
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Pro</h3>
                <div className="text-3xl font-bold text-gray-900 dark:text-white mb-6">9€<span className="text-sm text-gray-500">/mois</span></div>
                <ul className="space-y-3 text-gray-600 dark:text-gray-300 mb-8">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />Documents illimités</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />Quiz illimités</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />IA avancée</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />Support prioritaire</li>
                </ul>
                <Button asChild className="w-full bg-primary-500 hover:bg-primary-600">
                  <Link href="/register">Choisir Pro</Link>
                </Button>
              </CardContent>
            </Card>
            
            {/* Enterprise Plan */}
            <Card className="p-8 text-center relative">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Enterprise</h3>
                <div className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Sur mesure</div>
                <ul className="space-y-3 text-gray-600 dark:text-gray-300 mb-8">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />API personnalisée</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />Intégrations SSO</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />Support dédié</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-green-500 mr-2" />Formation équipe</li>
                </ul>
                <Button asChild variant="outline" className="w-full">
                  <Link href="/contact">Nous contacter</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-secondary-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl lg:text-5xl font-bold text-white">
                Prêt à transformer votre façon d'apprendre ?
              </h2>
              <p className="text-xl text-white/90 leading-relaxed">
                Rejoignez des milliers d'étudiants et professionnels qui utilisent déjà Orria pour atteindre leurs objectifs
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-primary-600 hover:bg-gray-50 px-8 py-4 text-lg font-semibold shadow-lg transform hover:scale-105 transition-all">
                <Link href="/register">
                  <Rocket className="w-5 h-5 mr-2" />
                  Commencer gratuitement
                </Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-2 border-white text-white hover:bg-white hover:text-primary-600 px-8 py-4 text-lg font-semibold"
                onClick={() => {
                  window.open('mailto:demo@orria.app?subject=Demande de démo&body=Bonjour, je souhaite planifier une démo d\'Orria.', '_blank');
                }}
              >
                <Calendar className="w-5 h-5 mr-2" />
                Planifier une démo
              </Button>
            </div>
            
            <div className="flex justify-center items-center space-x-8 text-white/80 text-sm">
              <div className="flex items-center">
                <CheckCircle className="w-4 h-4 mr-2" />
                Aucune carte requise
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-4 h-4 mr-2" />
                Annulation à tout moment
              </div>
              <SatisfiedUsersCounter />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
