import { useQuery } from '@tanstack/react-query';
import { getAuthHeaders } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useUser } from '@/hooks/use-user';
import StatsCards from '@/components/dashboard/stats-cards';
import ProgressChart from '@/components/dashboard/progress-chart';
import ActivityFeed from '@/components/dashboard/activity-feed';
import UpcomingTasks from '@/components/dashboard/upcoming-tasks';
import Badges from '@/components/dashboard/badges';
import { Plus, Upload, Users } from 'lucide-react';
import { Link } from 'wouter';

interface DashboardStats {
  totalTasks: number;
  completedTasks: number;
  totalQuizzes: number;
  completedQuizzes: number;
  averageScore: number;
  studyTimeThisWeek: number;
  upcomingTasks: any[];
  recentActivity: any[];
}

export default function Dashboard() {
  const { user } = useUser();

  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
    queryFn: async () => {
      const response = await fetch('/api/dashboard/stats', {
        headers: getAuthHeaders()
      });
      if (!response.ok) {
        throw new Error('Erreur lors du chargement des statistiques');
      }
      return response.json();
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Chargement de votre tableau de bord...</p>
        </div>
      </div>
    );
  }

  const progressPercentage = stats?.totalTasks ? Math.round((stats.completedTasks / stats.totalTasks) * 100) : 0;

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Dashboard Header */}
        <Card className="rounded-3xl shadow-2xl overflow-hidden mb-8">
          <div className="bg-gradient-to-r from-primary-500 to-secondary-500 p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-semibold">{user?.name}</h1>
                  <p className="text-white/80 text-sm capitalize">
                    {user?.role === 'student' ? 'Étudiant' : 'Professionnel'}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <div className="text-3xl font-bold">{progressPercentage}%</div>
                  <div className="text-sm text-white/80">Progression globale</div>
                </div>
                <div className="w-16 h-16 relative">
                  <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 36 36">
                    <path 
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" 
                      fill="none" 
                      stroke="rgba(255,255,255,0.2)" 
                      strokeWidth="2"
                    />
                    <path 
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" 
                      fill="none" 
                      stroke="white" 
                      strokeWidth="2" 
                      strokeDasharray={`${progressPercentage}, 100`}
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Dashboard Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Stats Cards */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Stats */}
            {stats && <StatsCards stats={stats} />}
            
            {/* Progress Chart */}
            <ProgressChart />
            
            {/* Recent Activity */}
            {stats && <ActivityFeed activities={stats.recentActivity} />}
          </div>
          
          {/* Right Column - Upcoming Tasks & Badges */}
          <div className="space-y-6">
            {/* Upcoming Tasks */}
            {stats && <UpcomingTasks tasks={stats.upcomingTasks} />}
            
            {/* Achievement Badges */}
            <Badges />
            
            {/* Quick Actions */}
            <div className="space-y-2">
              <Button asChild className="w-full bg-primary-500 hover:bg-primary-600 text-white">
                <Link href="/quiz">
                  <Plus className="w-4 h-4 mr-2" />
                  Nouveau quiz
                </Link>
              </Button>
              <Button asChild className="w-full bg-secondary-500 hover:bg-secondary-600 text-white">
                <Link href="/documents">
                  <Upload className="w-4 h-4 mr-2" />
                  Ajouter document
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
