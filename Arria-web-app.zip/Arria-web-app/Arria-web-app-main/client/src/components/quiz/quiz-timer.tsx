import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Clock, AlertTriangle } from 'lucide-react';

interface QuizTimerProps {
  duration: number; // in seconds
  onTimeUp: () => void;
  startTime: Date;
}

export default function QuizTimer({ duration, onTimeUp, startTime }: QuizTimerProps) {
  const [timeLeft, setTimeLeft] = useState(duration);
  const [isWarning, setIsWarning] = useState(false);
  const [isDanger, setIsDanger] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime.getTime()) / 1000);
      const remaining = Math.max(0, duration - elapsed);
      
      setTimeLeft(remaining);
      
      // Set warning states
      const percentLeft = (remaining / duration) * 100;
      setIsWarning(percentLeft <= 30 && percentLeft > 10);
      setIsDanger(percentLeft <= 10);
      
      if (remaining === 0) {
        clearInterval(interval);
        onTimeUp();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [duration, onTimeUp, startTime]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getTimerColor = () => {
    if (isDanger) return 'bg-red-500 text-white';
    if (isWarning) return 'bg-yellow-500 text-black';
    return 'bg-blue-500 text-white';
  };

  const getProgressWidth = () => {
    return Math.max(0, (timeLeft / duration) * 100);
  };

  return (
    <div className="flex items-center space-x-3">
      <Badge className={`px-3 py-1 font-mono text-sm ${getTimerColor()}`}>
        <Clock className="w-4 h-4 mr-1" />
        {formatTime(timeLeft)}
      </Badge>
      
      {isDanger && (
        <div className="flex items-center text-red-500 animate-pulse">
          <AlertTriangle className="w-4 h-4 mr-1" />
          <span className="text-sm font-medium">Temps presque écoulé !</span>
        </div>
      )}
      
      {/* Progress bar */}
      <div className="hidden sm:flex items-center space-x-2">
        <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-all duration-1000 ${
              isDanger ? 'bg-red-500' : isWarning ? 'bg-yellow-500' : 'bg-blue-500'
            }`}
            style={{ width: `${getProgressWidth()}%` }}
          ></div>
        </div>
        <span className="text-xs text-gray-500 min-w-[3rem]">
          {Math.round(getProgressWidth())}%
        </span>
      </div>
    </div>
  );
}
