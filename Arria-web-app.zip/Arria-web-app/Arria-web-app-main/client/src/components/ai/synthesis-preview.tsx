import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, FileText, Clock, CheckCircle, AlertCircle, Loader, Zap, Download } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface Document {
  id: string;
  title: string;
  originalName: string;
  fileType: string;
  fileSize: number;
  content?: string;
  summary?: string;
  keyPoints?: string[];
  synthesisStatus: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: string;
  subjectId?: string;
}

interface SynthesisPreviewProps {
  document: Document;
}

export default function SynthesisPreview({ document }: SynthesisPreviewProps) {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getStatusInfo = (status: Document['synthesisStatus']) => {
    switch (status) {
      case 'completed':
        return {
          icon: CheckCircle,
          text: 'Synthèse terminée',
          color: 'text-green-500',
          bgColor: 'bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800'
        };
      case 'processing':
        return {
          icon: Loader,
          text: 'Synthèse en cours...',
          color: 'text-blue-500',
          bgColor: 'bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800',
          animate: 'animate-spin'
        };
      case 'failed':
        return {
          icon: AlertCircle,
          text: 'Échec de la synthèse',
          color: 'text-red-500',
          bgColor: 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800'
        };
      default:
        return {
          icon: Clock,
          text: 'En attente...',
          color: 'text-yellow-500',
          bgColor: 'bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800'
        };
    }
  };

  const statusInfo = getStatusInfo(document.synthesisStatus);
  const StatusIcon = statusInfo.icon;

  const handleGenerateQuiz = async () => {
    try {
      const response = await fetch(`/api/documents/${document.id}/generate-quiz`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ numQuestions: 10 })
      });

      if (!response.ok) {
        throw new Error('Erreur lors de la génération du quiz');
      }

      const quiz = await response.json();
      window.location.href = `/quiz/${quiz.id}`;
    } catch (error) {
      console.error('Error generating quiz:', error);
    }
  };

  return (
    <Card className="sticky top-8">
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <FileText className="w-5 h-5 mr-2" />
          Détails du document
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Document Info */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900 dark:text-white truncate" title={document.title}>
            {document.title}
          </h3>
          
          <div className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
            <div>Fichier: {document.originalName}</div>
            <div>Taille: {formatFileSize(document.fileSize)}</div>
            <div>Type: {document.fileType}</div>
            <div>Ajouté: {format(new Date(document.createdAt), 'dd/MM/yyyy à HH:mm', { locale: fr })}</div>
          </div>
        </div>

        {/* Status */}
        <div className={`p-4 rounded-lg border ${statusInfo.bgColor}`}>
          <div className="flex items-center space-x-2">
            <StatusIcon className={`w-5 h-5 ${statusInfo.color} ${statusInfo.animate || ''}`} />
            <span className={`font-medium ${statusInfo.color}`}>{statusInfo.text}</span>
          </div>
        </div>

        {/* AI Synthesis Results */}
        {document.synthesisStatus === 'completed' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-purple-600 dark:text-purple-400">
              <Brain className="w-5 h-5" />
              <h4 className="font-semibold">Synthèse IA</h4>
            </div>

            {/* Summary */}
            {document.summary && (
              <div className="space-y-2">
                <h5 className="font-medium text-gray-900 dark:text-white text-sm">Résumé</h5>
                <div className="text-sm text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-800 p-3 rounded-lg max-h-40 overflow-y-auto">
                  {document.summary}
                </div>
              </div>
            )}

            {/* Key Points */}
            {document.keyPoints && document.keyPoints.length > 0 && (
              <div className="space-y-2">
                <h5 className="font-medium text-gray-900 dark:text-white text-sm">Points clés</h5>
                <div className="space-y-1">
                  {document.keyPoints.slice(0, 5).map((point, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <div className="w-1.5 h-1.5 bg-primary-500 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-sm text-gray-700 dark:text-gray-300">{point}</span>
                    </div>
                  ))}
                  {document.keyPoints.length > 5 && (
                    <div className="text-xs text-gray-500 pl-3.5">
                      +{document.keyPoints.length - 5} autres points...
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Processing State */}
        {document.synthesisStatus === 'processing' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-blue-600 dark:text-blue-400">
              <Brain className="w-5 h-5" />
              <h4 className="font-semibold">Analyse IA en cours</h4>
            </div>
            
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-green-700 dark:text-green-300">Document analysé</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-green-700 dark:text-green-300">Contenu extrait</span>
              </div>
              <div className="flex items-center space-x-2">
                <Loader className="w-4 h-4 text-blue-500 animate-spin" />
                <span className="text-blue-700 dark:text-blue-300">Génération de la synthèse...</span>
              </div>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-2 pt-4 border-t border-gray-200 dark:border-gray-700">
          {document.synthesisStatus === 'completed' && (
            <Button 
              onClick={handleGenerateQuiz}
              className="w-full bg-secondary-500 hover:bg-secondary-600"
            >
              <Zap className="w-4 h-4 mr-2" />
              Générer un quiz
            </Button>
          )}
          
          <Button variant="outline" className="w-full">
            <Download className="w-4 h-4 mr-2" />
            Télécharger
          </Button>
        </div>

        {/* Tips */}
        <div className="text-xs text-gray-500 bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
          <p className="mb-1">💡 <strong>Astuce:</strong></p>
          <p>La synthèse IA extrait automatiquement les concepts clés et génère des résumés pour optimiser vos révisions.</p>
        </div>
      </CardContent>
    </Card>
  );
}
