import { Card, CardContent } from '@/components/ui/card';
import { BookOpen, CheckCircle, Clock, TrendingUp } from 'lucide-react';

interface StatsCardsProps {
  stats: {
    totalTasks: number;
    completedTasks: number;
    totalQuizzes: number;
    completedQuizzes: number;
    averageScore: number;
    studyTimeThisWeek: number;
  };
}

export default function StatsCards({ stats }: StatsCardsProps) {
  const completionRate = stats.totalTasks > 0 ? Math.round((stats.completedTasks / stats.totalTasks) * 100) : 0;
  const studyHours = Math.floor(stats.studyTimeThisWeek / 60);

  return (
    <div className="grid md:grid-cols-3 gap-4">
      <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-100 dark:border-blue-800">
        <CardContent className="p-0">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">{stats.totalTasks}</div>
              <div className="text-sm text-blue-600 dark:text-blue-400">
                Tâches ({stats.completedTasks} terminées)
              </div>
            </div>
            <BookOpen className="w-8 h-8 text-blue-500" />
          </div>
          <div className="mt-2 text-xs text-blue-600 dark:text-blue-400">
            Taux de completion: {completionRate}%
          </div>
        </CardContent>
      </Card>

      <Card className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 border-green-100 dark:border-green-800">
        <CardContent className="p-0">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-green-700 dark:text-green-300">{stats.completedQuizzes}</div>
              <div className="text-sm text-green-600 dark:text-green-400">Quiz complétés</div>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
          <div className="mt-2 text-xs text-green-600 dark:text-green-400">
            Score moyen: {Math.round(stats.averageScore)}%
          </div>
        </CardContent>
      </Card>

      <Card className="p-6 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950 border-amber-100 dark:border-amber-800">
        <CardContent className="p-0">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-amber-700 dark:text-amber-300">{studyHours}h</div>
              <div className="text-sm text-amber-600 dark:text-amber-400">Temps d'étude</div>
            </div>
            <Clock className="w-8 h-8 text-amber-500" />
          </div>
          <div className="mt-2 text-xs text-amber-600 dark:text-amber-400">
            Cette semaine
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
