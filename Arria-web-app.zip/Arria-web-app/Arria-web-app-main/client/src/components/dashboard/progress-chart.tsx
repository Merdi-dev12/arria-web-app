import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getAuthHeaders } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface Subject {
  id: string;
  name: string;
  color: string;
}

interface Progress {
  subjectId?: string;
  studyTime: number;
  tasksCompleted: number;
  quizzesCompleted: number;
  averageScore?: number;
}

export default function ProgressChart() {
  // Fetch subjects
  const { data: subjects = [] } = useQuery<Subject[]>({
    queryKey: ['/api/subjects'],
    queryFn: async () => {
      const response = await fetch('/api/subjects', {
        headers: getAuthHeaders()
      });
      return response.json();
    }
  });

  // Fetch real progress data
  const { data: progressData = [] } = useQuery<Progress[]>({
    queryKey: ['/api/progress'],
    queryFn: async () => {
      const response = await fetch('/api/progress', {
        headers: getAuthHeaders()
      });
      return response.json();
    }
  });

  const getSubjectByProgress = (progress: Progress) => {
    return subjects.find(s => s.id === progress.subjectId);
  };

  const getProgressPercentage = (progress: Progress) => {
    // Calculate progress based on tasks completed and quizzes completed
    const tasksWeight = 0.6;
    const quizzesWeight = 0.4;
    
    // Assume max 20 tasks and 10 quizzes per subject for percentage calculation
    const taskProgress = Math.min((progress.tasksCompleted / 20) * 100, 100);
    const quizProgress = Math.min((progress.quizzesCompleted / 10) * 100, 100);
    
    return Math.round(taskProgress * tasksWeight + quizProgress * quizzesWeight);
  };

  return (
    <Card className="bg-gray-50 dark:bg-gray-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
          Progression par matière
        </CardTitle>
      </CardHeader>
      <CardContent>
        {subjects.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500 dark:text-gray-400">
              Ajoutez des matières pour voir votre progression
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {progressData.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">
                  Commencez à étudier pour voir votre progression
                </p>
              </div>
            ) : (
              progressData.map((progress, index) => {
                const subject = getSubjectByProgress(progress);
                if (!subject) return null;

                const progressPercentage = getProgressPercentage(progress);

                return (
                  <div key={`${subject.id}-${index}`} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: subject.color }}
                        ></div>
                        <span className="text-gray-700 dark:text-gray-300 font-medium">
                          {subject.name}
                        </span>
                        {progress.averageScore && (
                          <Badge variant="outline" className="text-xs">
                            {progress.averageScore}% avg
                          </Badge>
                        )}
                      </div>
                      <span className="text-sm font-semibold text-gray-900 dark:text-white">
                        {progressPercentage}%
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="flex-1 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div 
                          className="h-2 rounded-full transition-all duration-500"
                          style={{ 
                            width: `${progressPercentage}%`,
                            backgroundColor: subject.color
                          }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
                      <span>{progress.tasksCompleted} tâches</span>
                      <span>{progress.quizzesCompleted} quiz</span>
                      <span>{Math.floor(progress.studyTime / 60)}h étude</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
