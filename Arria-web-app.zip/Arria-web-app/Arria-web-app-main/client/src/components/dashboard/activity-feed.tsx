import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, FileText, Trophy, Zap } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface Activity {
  type: string;
  id: string;
  title: string;
  score?: number;
  totalQuestions?: number;
  timestamp: string;
  icon: string;
  color: string;
}

interface ActivityFeedProps {
  activities: Activity[];
}

export default function ActivityFeed({ activities }: ActivityFeedProps) {
  const getIcon = (iconName: string, color: string) => {
    const iconClass = `w-5 h-5 text-${color}-500`;
    
    switch (iconName) {
      case 'check-circle':
        return <CheckCircle className={iconClass} />;
      case 'question-circle':
        return <Zap className={iconClass} />;
      case 'file-alt':
        return <FileText className={iconClass} />;
      case 'trophy':
        return <Trophy className={iconClass} />;
      default:
        return <CheckCircle className={iconClass} />;
    }
  };

  const getActivityText = (activity: Activity) => {
    switch (activity.type) {
      case 'task':
        return 'Tâche terminée';
      case 'quiz':
        return `Quiz complété - Score: ${activity.score}/${activity.totalQuestions}`;
      case 'document':
        return 'Document synthétisé';
      case 'badge':
        return 'Badge débloqué';
      default:
        return 'Activité';
    }
  };

  const getBackgroundColor = (color: string) => {
    switch (color) {
      case 'green':
        return 'bg-green-50 dark:bg-green-950 border-green-100 dark:border-green-800';
      case 'blue':
        return 'bg-blue-50 dark:bg-blue-950 border-blue-100 dark:border-blue-800';
      case 'purple':
        return 'bg-purple-50 dark:bg-purple-950 border-purple-100 dark:border-purple-800';
      case 'yellow':
        return 'bg-yellow-50 dark:bg-yellow-950 border-yellow-100 dark:border-yellow-800';
      default:
        return 'bg-gray-50 dark:bg-gray-800 border-gray-100 dark:border-gray-700';
    }
  };

  return (
    <Card className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
          Activité récente
        </CardTitle>
      </CardHeader>
      <CardContent>
        {activities.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-gray-400 mb-2">
              <CheckCircle className="w-12 h-12 mx-auto" />
            </div>
            <p className="text-gray-500 dark:text-gray-400">
              Aucune activité récente
            </p>
            <p className="text-sm text-gray-400 mt-1">
              Vos actions apparaîtront ici
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {activities.map((activity, index) => (
              <div 
                key={`${activity.id}-${index}`} 
                className={`flex items-center space-x-3 p-3 rounded-lg border ${getBackgroundColor(activity.color)}`}
              >
                {getIcon(activity.icon, activity.color)}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-gray-900 dark:text-white truncate">
                    {activity.title}
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    {getActivityText(activity)} • {format(new Date(activity.timestamp), 'dd/MM à HH:mm', { locale: fr })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
