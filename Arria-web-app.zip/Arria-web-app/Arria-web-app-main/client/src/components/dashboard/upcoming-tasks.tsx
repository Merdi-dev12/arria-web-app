import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, AlertTriangle } from 'lucide-react';
import { format, differenceInDays, differenceInHours } from 'date-fns';
import { fr } from 'date-fns/locale';

interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate?: string;
  priority: number;
}

interface UpcomingTasksProps {
  tasks: Task[];
}

export default function UpcomingTasks({ tasks }: UpcomingTasksProps) {
  const getUrgencyLevel = (dueDate: string) => {
    const now = new Date();
    const due = new Date(dueDate);
    const hoursUntilDue = differenceInHours(due, now);
    const daysUntilDue = differenceInDays(due, now);

    if (hoursUntilDue < 24) {
      return { level: 'critical', text: 'Urgent', color: 'red' };
    } else if (daysUntilDue <= 2) {
      return { level: 'high', text: 'Bientôt', color: 'orange' };
    } else {
      return { level: 'normal', text: 'À venir', color: 'green' };
    }
  };

  const getPriorityColor = (priority: number) => {
    switch (priority) {
      case 3: return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 2: return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default: return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    }
  };

  const getPriorityLabel = (priority: number) => {
    switch (priority) {
      case 3: return 'Haute';
      case 2: return 'Moyenne';
      default: return 'Basse';
    }
  };

  const formatDueDate = (dueDate: string) => {
    const now = new Date();
    const due = new Date(dueDate);
    const daysUntilDue = differenceInDays(due, now);
    const hoursUntilDue = differenceInHours(due, now);

    if (daysUntilDue === 0) {
      if (hoursUntilDue <= 1) {
        return 'Dans moins d\'1h';
      } else {
        return `Dans ${hoursUntilDue}h`;
      }
    } else if (daysUntilDue === 1) {
      return 'Demain';
    } else if (daysUntilDue <= 7) {
      return `Dans ${daysUntilDue} jours`;
    } else {
      return format(due, 'dd/MM/yyyy', { locale: fr });
    }
  };

  return (
    <Card className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
          Prochaines échéances
        </CardTitle>
      </CardHeader>
      <CardContent>
        {tasks.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500 dark:text-gray-400">
              Aucune échéance proche
            </p>
            <p className="text-sm text-gray-400 mt-1">
              Vos prochaines tâches apparaîtront ici
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map((task) => {
              const urgency = task.dueDate ? getUrgencyLevel(task.dueDate) : null;
              
              return (
                <div 
                  key={task.id}
                  className={`flex items-start space-x-3 p-3 rounded-lg border transition-colors ${
                    urgency?.level === 'critical' 
                      ? 'bg-red-50 dark:bg-red-950 border-red-100 dark:border-red-800'
                      : urgency?.level === 'high'
                      ? 'bg-orange-50 dark:bg-orange-950 border-orange-100 dark:border-orange-800'
                      : 'bg-green-50 dark:bg-green-950 border-green-100 dark:border-green-800'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    urgency?.level === 'critical' ? 'bg-red-500' :
                    urgency?.level === 'high' ? 'bg-orange-500' : 'bg-green-500'
                  }`}></div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                          {task.title}
                        </h4>
                        {urgency && (
                          <Badge className={`text-xs px-1.5 py-0.5 ${
                            urgency.level === 'critical' ? 'bg-red-500 text-white' :
                            urgency.level === 'high' ? 'bg-orange-500 text-white' :
                            'bg-green-500 text-white'
                          }`}>
                            {urgency.text}
                          </Badge>
                        )}
                      </div>
                      
                      <Badge className={getPriorityColor(task.priority)}>
                        {getPriorityLabel(task.priority)}
                      </Badge>
                    </div>
                    
                    {task.description && (
                      <p className="text-xs text-gray-600 dark:text-gray-300 mb-2 truncate">
                        {task.description}
                      </p>
                    )}
                    
                    {task.dueDate && (
                      <div className={`text-xs flex items-center ${
                        urgency?.level === 'critical' ? 'text-red-600 dark:text-red-400' :
                        urgency?.level === 'high' ? 'text-orange-600 dark:text-orange-400' :
                        'text-green-600 dark:text-green-400'
                      }`}>
                        {urgency?.level === 'critical' && <AlertTriangle className="w-3 h-3 mr-1" />}
                        <Clock className="w-3 h-3 mr-1" />
                        {formatDueDate(task.dueDate)}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
