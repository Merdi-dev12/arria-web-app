import { useQuery } from '@tanstack/react-query';
import { getAuthHeaders } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Trophy, 
  Star, 
  Award, 
  Target, 
  Zap, 
  BookOpen, 
  Calendar,
  CheckCircle,
  Flame
} from 'lucide-react';

interface UserBadge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  earnedAt: string;
}

interface BadgesData {
  earned: UserBadge[];
  available: any[];
}

export default function BadgesSection() {
  const { data: badgesData, isLoading } = useQuery<BadgesData>({
    queryKey: ['/api/badges'],
    queryFn: async () => {
      const response = await fetch('/api/badges', {
        headers: getAuthHeaders()
      });
      return response.json();
    }
  });

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'trophy':
        return Trophy;
      case 'star':
        return Star;
      case 'award':
        return Award;
      case 'target':
        return Target;
      case 'zap':
        return Zap;
      case 'book-open':
        return BookOpen;
      case 'calendar':
        return Calendar;
      case 'check-circle':
        return CheckCircle;
      case 'flame':
        return Flame;
      default:
        return Trophy;
    }
  };

  const earnedBadges = badgesData?.earned || [];

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-purple-100 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
            Badges récents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-purple-100 dark:border-purple-800">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
          Badges récents
        </CardTitle>
      </CardHeader>
      <CardContent>
        {earnedBadges.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-purple-400 mb-4">
              <Trophy className="w-12 h-12 mx-auto" />
            </div>
            <p className="text-gray-500 dark:text-gray-400">
              Aucun badge obtenu
            </p>
            <p className="text-sm text-gray-400 mt-1">
              Terminez vos premières tâches pour débloquer des badges !
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {earnedBadges.slice(0, 4).map((badge: UserBadge, index: number) => {
              const IconComponent = getIconComponent(badge.icon);
              
              return (
                <Card 
                  key={badge.id} 
                  className="text-center p-3 shadow-sm transition-all hover:scale-105"
                >
                  <CardContent className="p-0">
                    <div className="flex flex-col items-center space-y-2">
                      <div 
                        className="w-8 h-8 rounded-full flex items-center justify-center"
                        style={{ 
                          backgroundColor: badge.color + '20',
                          color: badge.color
                        }}
                      >
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div className="text-xs font-medium text-gray-900 dark:text-white text-center leading-tight">
                        {badge.name}
                      </div>
                      <Badge className="text-xs px-1 py-0 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                        Obtenu
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}