import { 
  type User, 
  type InsertUser, 
  type Subject, 
  type InsertSubject,
  type Course,
  type InsertCourse,
  type Task,
  type InsertTask,
  type Document,
  type InsertDocument,
  type Quiz,
  type InsertQuiz,
  type Progress,
  type InsertProgress,
  type Badge,
  type UserBadge,
  users,
  subjects,
  courses,
  tasks,
  documents,
  quizzes,
  progress,
  badges,
  userBadges
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Subjects
  getSubjectsByUserId(userId: string): Promise<Subject[]>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  
  // Courses
  getCoursesByUserId(userId: string): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Tasks
  getTasksByUserId(userId: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task>;
  
  // Documents
  getDocumentsByUserId(userId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: string, document: Partial<InsertDocument>): Promise<Document>;
  getDocument(id: string): Promise<Document | undefined>;
  
  // Quizzes
  getQuizzesByUserId(userId: string): Promise<Quiz[]>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  updateQuiz(id: string, quiz: Partial<InsertQuiz>): Promise<Quiz>;
  getQuiz(id: string): Promise<Quiz | undefined>;
  
  // Progress
  getProgressByUserId(userId: string): Promise<Progress[]>;
  createProgress(progressData: InsertProgress): Promise<Progress>;
  
  // Badges
  getBadges(): Promise<Badge[]>;
  getUserBadges(userId: string): Promise<(UserBadge & { badge: Badge })[]>;
  awardBadge(userId: string, badgeId: string): Promise<UserBadge>;
  
  // Dashboard Stats
  getDashboardStats(userId: string): Promise<{
    totalTasks: number;
    completedTasks: number;
    totalQuizzes: number;
    completedQuizzes: number;
    averageScore: number;
    studyTimeThisWeek: number;
    upcomingTasks: Task[];
    recentActivity: any[];
  }>;
  
  // Public Stats
  getSatisfiedUsersCount(): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getSubjectsByUserId(userId: string): Promise<Subject[]> {
    return await db.select().from(subjects).where(eq(subjects.userId, userId));
  }

  async createSubject(subject: InsertSubject): Promise<Subject> {
    const [newSubject] = await db
      .insert(subjects)
      .values(subject)
      .returning();
    return newSubject;
  }

  async getCoursesByUserId(userId: string): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.userId, userId));
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db
      .insert(courses)
      .values(course)
      .returning();
    return newCourse;
  }

  async getTasksByUserId(userId: string): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.userId, userId)).orderBy(desc(tasks.createdAt));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateTask(id: string, task: Partial<InsertTask>): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ ...task, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask;
  }

  async getDocumentsByUserId(userId: string): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.userId, userId)).orderBy(desc(documents.createdAt));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db
      .insert(documents)
      .values(document)
      .returning();
    return newDocument;
  }

  async updateDocument(id: string, document: Partial<InsertDocument>): Promise<Document> {
    const [updatedDocument] = await db
      .update(documents)
      .set(document)
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const [document] = await db.select().from(documents).where(eq(documents.id, id));
    return document || undefined;
  }

  async getQuizzesByUserId(userId: string): Promise<Quiz[]> {
    return await db.select().from(quizzes).where(eq(quizzes.userId, userId)).orderBy(desc(quizzes.createdAt));
  }

  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const [newQuiz] = await db
      .insert(quizzes)
      .values(quiz)
      .returning();
    return newQuiz;
  }

  async updateQuiz(id: string, quiz: Partial<InsertQuiz>): Promise<Quiz> {
    const [updatedQuiz] = await db
      .update(quizzes)
      .set(quiz)
      .where(eq(quizzes.id, id))
      .returning();
    return updatedQuiz;
  }

  async getQuiz(id: string): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz || undefined;
  }

  async getProgressByUserId(userId: string): Promise<Progress[]> {
    return await db.select().from(progress).where(eq(progress.userId, userId)).orderBy(desc(progress.date));
  }

  async createProgress(progressData: InsertProgress): Promise<Progress> {
    const [newProgress] = await db
      .insert(progress)
      .values(progressData)
      .returning();
    return newProgress;
  }

  async getBadges(): Promise<Badge[]> {
    return await db.select().from(badges);
  }

  async getUserBadges(userId: string): Promise<(UserBadge & { badge: Badge })[]> {
    return await db
      .select({
        id: userBadges.id,
        userId: userBadges.userId,
        badgeId: userBadges.badgeId,
        earnedAt: userBadges.earnedAt,
        badge: badges
      })
      .from(userBadges)
      .innerJoin(badges, eq(userBadges.badgeId, badges.id))
      .where(eq(userBadges.userId, userId));
  }

  async awardBadge(userId: string, badgeId: string): Promise<UserBadge> {
    const [newUserBadge] = await db
      .insert(userBadges)
      .values({ userId, badgeId })
      .returning();
    return newUserBadge;
  }

  async getDashboardStats(userId: string): Promise<{
    totalTasks: number;
    completedTasks: number;
    totalQuizzes: number;
    completedQuizzes: number;
    averageScore: number;
    studyTimeThisWeek: number;
    upcomingTasks: Task[];
    recentActivity: any[];
  }> {
    const userTasks = await db.select().from(tasks).where(eq(tasks.userId, userId));
    const userQuizzes = await db.select().from(quizzes).where(eq(quizzes.userId, userId));
    
    const totalTasks = userTasks.length;
    const completedTasks = userTasks.filter(task => task.status === 'completed').length;
    const totalQuizzes = userQuizzes.length;
    const completedQuizzes = userQuizzes.filter(quiz => quiz.status === 'completed').length;
    
    const completedQuizzesWithScore = userQuizzes.filter(quiz => quiz.status === 'completed' && quiz.score);
    const averageScore = completedQuizzesWithScore.length > 0 
      ? completedQuizzesWithScore.reduce((sum, quiz) => sum + (quiz.score || 0), 0) / completedQuizzesWithScore.length 
      : 0;

    // Get study time for this week
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    
    const weekProgress = await db
      .select()
      .from(progress)
      .where(and(
        eq(progress.userId, userId),
        sql`${progress.date} >= ${weekStart}`
      ));
    
    const studyTimeThisWeek = weekProgress.reduce((sum, p) => sum + p.studyTime, 0);

    // Get upcoming tasks (due in next 7 days)
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    
    const upcomingTasks = await db
      .select()
      .from(tasks)
      .where(and(
        eq(tasks.userId, userId),
        sql`${tasks.dueDate} <= ${nextWeek}`,
        sql`${tasks.status} != 'completed'`
      ))
      .orderBy(tasks.dueDate)
      .limit(5);

    // Recent activity - mix of completed tasks and quizzes
    const recentCompletedTasks = await db
      .select()
      .from(tasks)
      .where(and(
        eq(tasks.userId, userId),
        eq(tasks.status, 'completed')
      ))
      .orderBy(desc(tasks.updatedAt))
      .limit(3);

    const recentCompletedQuizzes = await db
      .select()
      .from(quizzes)
      .where(and(
        eq(quizzes.userId, userId),
        eq(quizzes.status, 'completed')
      ))
      .orderBy(desc(quizzes.completedAt))
      .limit(3);

    const recentActivity = [
      ...recentCompletedTasks.map(task => ({
        type: 'task',
        id: task.id,
        title: task.title,
        timestamp: task.updatedAt,
        icon: 'check-circle',
        color: 'green'
      })),
      ...recentCompletedQuizzes.map(quiz => ({
        type: 'quiz',
        id: quiz.id,
        title: quiz.title,
        score: quiz.score,
        totalQuestions: quiz.totalQuestions,
        timestamp: quiz.completedAt,
        icon: 'question-circle',
        color: 'blue'
      }))
    ].sort((a, b) => {
      const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
      const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
      return dateB - dateA;
    }).slice(0, 5);

    return {
      totalTasks,
      completedTasks,
      totalQuizzes,
      completedQuizzes,
      averageScore,
      studyTimeThisWeek,
      upcomingTasks,
      recentActivity
    };
  }

  async getSatisfiedUsersCount(): Promise<number> {
    // For now, count users who have completed at least one task or quiz as "satisfied"
    // In the future, this could be based on user feedback/ratings
    const [result] = await db
      .select({ count: sql<number>`count(distinct ${users.id})` })
      .from(users)
      .leftJoin(tasks, eq(tasks.userId, users.id))
      .leftJoin(quizzes, eq(quizzes.userId, users.id))
      .where(
        sql`${tasks.status} = 'completed' OR ${quizzes.status} = 'completed'`
      );
    
    return result?.count || 0;
  }
}

export const storage = new DatabaseStorage();
