import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface SynthesisResult {
  summary: string;
  keyPoints: string[];
  concepts: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface QuizGenerationResult {
  questions: QuizQuestion[];
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedTime: number;
}

export async function synthesizeDocument(content: string, title: string): Promise<SynthesisResult> {
  try {
    const prompt = `Analysez le document suivant intitulé "${title}" et fournissez une synthèse structurée en français.

Document:
${content}

Générez une réponse JSON avec les champs suivants:
- summary: Un résumé concis du document (200-300 mots)
- keyPoints: Une liste de 5-8 points clés du document
- concepts: Une liste des concepts principaux abordés

Répondez uniquement en JSON.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Vous êtes un expert en synthèse de documents académiques. Vous analysez des documents et créez des résumés structurés en français."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      summary: result.summary || "Synthèse non disponible",
      keyPoints: result.keyPoints || [],
      concepts: result.concepts || []
    };
  } catch (error) {
    console.error("Error synthesizing document:", error);
    throw new Error("Échec de la synthèse du document: " + (error as Error).message);
  }
}

export async function generateQuiz(content: string, title: string, numQuestions: number = 10): Promise<QuizGenerationResult> {
  try {
    const prompt = `Créez un quiz de ${numQuestions} questions à choix multiples basé sur le document suivant intitulé "${title}".

Document:
${content}

Générez une réponse JSON avec les champs suivants:
- questions: Un tableau de ${numQuestions} questions avec:
  - id: un identifiant unique
  - question: la question en français
  - options: un tableau de 4 options de réponse
  - correctAnswer: l'index (0-3) de la réponse correcte
  - explanation: une explication de la réponse correcte
- difficulty: niveau de difficulté ('easy', 'medium', ou 'hard')
- estimatedTime: temps estimé en minutes pour compléter le quiz

Assurez-vous que les questions couvrent les concepts principaux du document et sont de difficulté progressive.

Répondez uniquement en JSON.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Vous êtes un expert en création de quiz éducatifs. Vous créez des questions pertinentes et équilibrées basées sur du contenu académique."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.4,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    // Ensure all questions have valid structure
    const questions = (result.questions || []).map((q: any, index: number) => ({
      id: q.id || `q_${index + 1}`,
      question: q.question || `Question ${index + 1}`,
      options: Array.isArray(q.options) && q.options.length === 4 ? q.options : ["Option A", "Option B", "Option C", "Option D"],
      correctAnswer: typeof q.correctAnswer === 'number' && q.correctAnswer >= 0 && q.correctAnswer <= 3 ? q.correctAnswer : 0,
      explanation: q.explanation || "Explication non disponible"
    }));

    return {
      questions: questions.slice(0, numQuestions),
      difficulty: ['easy', 'medium', 'hard'].includes(result.difficulty) ? result.difficulty : 'medium',
      estimatedTime: typeof result.estimatedTime === 'number' ? result.estimatedTime : numQuestions * 2
    };
  } catch (error) {
    console.error("Error generating quiz:", error);
    throw new Error("Échec de la génération du quiz: " + (error as Error).message);
  }
}

export async function generateStudyTips(userRole: 'student' | 'professional', subjects: string[], recentActivity: any[]): Promise<string[]> {
  try {
    const roleContext = userRole === 'student' 
      ? "étudiant cherchant à améliorer ses résultats académiques"
      : "professionnel cherchant à optimiser sa productivité";

    const prompt = `Vous conseillez un ${roleContext}. 

Matières/Domaines: ${subjects.join(', ')}
Activité récente: ${JSON.stringify(recentActivity)}

Générez 5 conseils personnalisés en français pour améliorer l'apprentissage et la productivité. 

Répondez avec un JSON contenant:
- tips: un tableau de 5 conseils pratiques et spécifiques

Répondez uniquement en JSON.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Vous êtes un coach en apprentissage et productivité. Vous donnez des conseils personnalisés et pratiques."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.tips || [];
  } catch (error) {
    console.error("Error generating study tips:", error);
    return ["Continuez vos efforts d'apprentissage de manière régulière."];
  }
}
