import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertSubjectSchema, insertTaskSchema, insertDocumentSchema, insertQuizSchema } from "@shared/schema";
import { synthesizeDocument, generateQuiz, generateStudyTips } from "./openai";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "path";
import fs from "fs";

const JWT_SECRET = process.env.JWT_SECRET || "orria-secret-key";
const upload = multer({ 
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

// Middleware to verify JWT token
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Token d\'accès requis' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Token invalide' });
    }
    req.user = user;
    next();
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Un compte existe déjà avec cet email" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);
      
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword
      });

      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({ 
        user: { 
          id: user.id, 
          email: user.email, 
          name: user.name, 
          role: user.role,
          avatar: user.avatar
        }, 
        token 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email et mot de passe requis" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Identifiants invalides" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Identifiants invalides" });
      }

      const token = jwt.sign(
        { userId: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({ 
        user: { 
          id: user.id, 
          email: user.email, 
          name: user.name, 
          role: user.role,
          avatar: user.avatar
        }, 
        token 
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User profile
  app.get("/api/auth/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      res.json({ 
        id: user.id, 
        email: user.email, 
        name: user.name, 
        role: user.role,
        avatar: user.avatar
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", authenticateToken, async (req: any, res) => {
    try {
      const stats = await storage.getDashboardStats(req.user.userId);
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Subjects
  app.get("/api/subjects", authenticateToken, async (req: any, res) => {
    try {
      const subjects = await storage.getSubjectsByUserId(req.user.userId);
      res.json(subjects);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/subjects", authenticateToken, async (req: any, res) => {
    try {
      const validatedData = insertSubjectSchema.parse({
        ...req.body,
        userId: req.user.userId
      });
      
      const subject = await storage.createSubject(validatedData);
      res.status(201).json(subject);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Tasks
  app.get("/api/tasks", authenticateToken, async (req: any, res) => {
    try {
      const tasks = await storage.getTasksByUserId(req.user.userId);
      res.json(tasks);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tasks", authenticateToken, async (req: any, res) => {
    try {
      const validatedData = insertTaskSchema.parse({
        ...req.body,
        userId: req.user.userId
      });
      
      const task = await storage.createTask(validatedData);
      res.status(201).json(task);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/tasks/:id", authenticateToken, async (req: any, res) => {
    try {
      const task = await storage.updateTask(req.params.id, req.body);
      res.json(task);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Documents
  app.get("/api/documents", authenticateToken, async (req: any, res) => {
    try {
      const documents = await storage.getDocumentsByUserId(req.user.userId);
      res.json(documents);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/documents/upload", authenticateToken, upload.single('file'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Aucun fichier fourni" });
      }

      // Read file content (simplified - in production, you'd use proper text extraction)
      const fileContent = fs.readFileSync(req.file.path, 'utf8');
      
      const document = await storage.createDocument({
        userId: req.user.userId,
        subjectId: req.body.subjectId || null,
        title: req.body.title || req.file.originalname,
        originalName: req.file.originalname,
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        filePath: req.file.path,
        content: fileContent,
        synthesisStatus: 'pending'
      });

      // Start AI synthesis in background
      synthesizeDocument(fileContent, document.title)
        .then(async (synthesis) => {
          await storage.updateDocument(document.id, {
            summary: synthesis.summary,
            keyPoints: synthesis.keyPoints,
            synthesisStatus: 'completed'
          });
        })
        .catch(async (error) => {
          console.error("Synthesis error:", error);
          await storage.updateDocument(document.id, {
            synthesisStatus: 'failed'
          });
        });

      res.status(201).json(document);
    } catch (error: any) {
      if (req.file) {
        fs.unlinkSync(req.file.path); // Clean up uploaded file on error
      }
      res.status(400).json({ message: error.message });
    }
  });

  // Generate quiz from document
  app.post("/api/documents/:id/generate-quiz", authenticateToken, async (req: any, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document || document.userId !== req.user.userId) {
        return res.status(404).json({ message: "Document non trouvé" });
      }

      if (!document.content) {
        return res.status(400).json({ message: "Le document n'a pas de contenu analysable" });
      }

      const numQuestions = req.body.numQuestions || 10;
      const quizData = await generateQuiz(document.content, document.title, numQuestions);
      
      const quiz = await storage.createQuiz({
        userId: req.user.userId,
        documentId: document.id,
        subjectId: document.subjectId,
        title: `Quiz - ${document.title}`,
        questions: quizData.questions,
        totalQuestions: quizData.questions.length,
        timeLimit: quizData.estimatedTime,
        status: 'not_started'
      });

      res.status(201).json(quiz);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Quizzes
  app.get("/api/quizzes", authenticateToken, async (req: any, res) => {
    try {
      const quizzes = await storage.getQuizzesByUserId(req.user.userId);
      res.json(quizzes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/quizzes/:id", authenticateToken, async (req: any, res) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      if (!quiz || quiz.userId !== req.user.userId) {
        return res.status(404).json({ message: "Quiz non trouvé" });
      }
      res.json(quiz);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/quizzes/:id/submit", authenticateToken, async (req: any, res) => {
    try {
      const { answers, timeSpent } = req.body;
      const quiz = await storage.getQuiz(req.params.id);
      
      if (!quiz || quiz.userId !== req.user.userId) {
        return res.status(404).json({ message: "Quiz non trouvé" });
      }

      // Calculate score
      const questions = quiz.questions as any[];
      let correctAnswers = 0;
      
      questions.forEach((question, index) => {
        if (answers[index] === question.correctAnswer) {
          correctAnswers++;
        }
      });

      const score = Math.round((correctAnswers / questions.length) * 100);
      
      const updatedQuiz = await storage.updateQuiz(req.params.id, {
        status: 'completed',
        score,
        timeSpent,
        completedAt: new Date()
      });

      res.json({
        quiz: updatedQuiz,
        score,
        correctAnswers,
        totalQuestions: questions.length
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AI Study Tips
  app.get("/api/ai/study-tips", authenticateToken, async (req: any, res) => {
    try {
      const subjects = await storage.getSubjectsByUserId(req.user.userId);
      const stats = await storage.getDashboardStats(req.user.userId);
      
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }

      const tips = await generateStudyTips(
        user.role,
        subjects.map(s => s.name),
        stats.recentActivity
      );
      
      res.json({ tips });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Badges
  app.get("/api/badges", authenticateToken, async (req: any, res) => {
    try {
      const userBadges = await storage.getUserBadges(req.user.userId);
      const allBadges = await storage.getBadges();
      
      res.json({
        earned: userBadges,
        available: allBadges
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Public stats (no authentication required)
  app.get("/api/stats/users", async (req, res) => {
    try {
      const satisfiedUsers = await storage.getSatisfiedUsersCount();
      res.json({ satisfiedUsers });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
