# Overview

Orria is a comprehensive educational management platform built as a full-stack web application. It serves as an AI-powered learning assistant for students and professionals, offering features like document synthesis, quiz generation, task management, progress tracking, and study planning. The platform integrates OpenAI's GPT models to provide intelligent content analysis and educational tools.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built with React 18 and TypeScript, utilizing a modern component-based architecture. The UI is constructed with Radix UI primitives and styled using Tailwind CSS with a custom design system. The application uses Wouter for lightweight client-side routing and TanStack Query for efficient server state management and caching. The component structure follows a clear separation with reusable UI components in `/components/ui/`, feature-specific components organized by domain, and pages handling route-level logic.

## Backend Architecture
The server follows a REST API architecture built with Express.js and TypeScript. The codebase is organized into distinct modules: route handlers in `/server/routes.ts`, database operations abstracted through a storage layer in `/server/storage.ts`, and AI integration services in `/server/openai.ts`. The server implements JWT-based authentication middleware and supports file uploads through Multer for document processing.

## Database Design
The application uses PostgreSQL with Drizzle ORM for type-safe database operations. The schema defines core entities including users with role-based access (students/professionals), subjects with color coding, courses with scheduling, tasks with priority and status tracking, documents with AI synthesis capabilities, quizzes with scoring, progress tracking, and a badge system for gamification. All tables use UUID primary keys and include proper foreign key relationships with timestamps for audit trails.

## Authentication & Authorization
Security is implemented through bcrypt password hashing and JWT token-based authentication. The system supports user registration and login with role differentiation between students and professionals. Authentication middleware protects API routes, and the frontend maintains auth state through React context with localStorage persistence.

## AI Integration
OpenAI's GPT-4 model powers the platform's intelligent features. The AI service handles document synthesis by analyzing uploaded files and generating structured summaries with key points and concepts. It also provides quiz generation with multiple-choice questions, explanations, and difficulty assessment. The integration includes proper error handling and response formatting for consistent user experience.

## File Management
The platform supports document uploads with a 10MB size limit using Multer middleware. Files are processed asynchronously for AI synthesis, with status tracking through database states (pending, processing, completed, failed). The system maintains original filenames and metadata for user reference.

## State Management
The frontend employs a layered state management approach: TanStack Query handles server state with caching and synchronization, React Context manages authentication state globally, and local component state handles UI interactions. This architecture ensures efficient data flow and minimal unnecessary re-renders.

# External Dependencies

## Core Runtime Dependencies
- **Express.js**: Web server framework for REST API
- **React 18**: Frontend UI framework with modern hooks
- **TypeScript**: Type safety across the entire codebase
- **Vite**: Build tool and development server with HMR

## Database & ORM
- **PostgreSQL**: Primary database via Neon serverless
- **Drizzle ORM**: Type-safe database operations and migrations
- **@neondatabase/serverless**: Serverless PostgreSQL client

## UI & Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Headless accessible component primitives
- **Lucide React**: Comprehensive icon library

## State Management & Data Fetching
- **TanStack Query**: Server state management and caching
- **Wouter**: Lightweight client-side routing

## Authentication & Security
- **bcrypt**: Password hashing
- **jsonwebtoken**: JWT token generation and verification

## AI & External Services
- **OpenAI API**: GPT-4 integration for document synthesis and quiz generation

## File Handling
- **Multer**: Multipart form data and file upload processing

## Development Tools
- **ESBuild**: Fast bundling for production builds
- **TSX**: TypeScript execution for development
- **Drizzle Kit**: Database migration management